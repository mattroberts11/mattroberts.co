== Framework Stylesheets ==

1) bootstrap.css => bootstrap.min.css (RTL generated, but not being used at this time)

2) fontawesome.css => fontawesome.min.css

3) magnific-popup.css => magnific-popup.min.css

4) grid-extended.css => grid-extended.min.css (RTL generated, but not being used at this time)

5) themeblvd.css => themeblvd.min.css
	* IF RTL: themeblvd-rtl.css (generated w/CSSJanus) => themeblvd-rtl.min.css

--------

*NOTE: For CSSJanus conversions set swap_ltr_rtl_in_url flag to true.*
