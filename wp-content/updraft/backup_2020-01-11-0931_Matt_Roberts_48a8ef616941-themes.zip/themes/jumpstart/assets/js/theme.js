jQuery(document).ready(function($){

	/* Put any theme-specific JS here. Not Enqueued by default. */

});
