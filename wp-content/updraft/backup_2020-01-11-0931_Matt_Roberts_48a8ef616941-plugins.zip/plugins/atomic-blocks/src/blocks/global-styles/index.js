/**
 * Import global styles.
 */
import './styles/style.scss';
import './styles/editor.scss';
